import globals from "globals"
import tsParser from "@typescript-eslint/parser"
import path from "node:path"
import { fileURLToPath } from "node:url"
import js from "@eslint/js"
import { FlatCompat } from "@eslint/eslintrc"

const filename = fileURLToPath(import.meta.url)
const dirname = path.dirname(filename)
const compat = new FlatCompat({
  baseDirectory: dirname,
  recommendedConfig: js.configs.recommended,
  allConfig: js.configs.all
})

export default [...compat.extends(
  "eslint:recommended",
  "plugin:@typescript-eslint/recommended",
  "prettier",
), {
  languageOptions: {
    globals: {
      ...globals.node,
    },

    parser: tsParser,
    ecmaVersion: "latest",
    sourceType: "commonjs",
  },

  rules: {
    "@typescript-eslint/no-explicit-any": "off",
    quotes: ["error", "double"],
    semi: ["error", "never"],
  },
}]